package com.CEN30241.nflms;

import com.CEN30241.nflms.Controllers.Menu;
import javafx.application.Application;


public class NFLApp {

    public static void main(String[] args) {
       Application.launch(Menu.class,args);
    }

}
